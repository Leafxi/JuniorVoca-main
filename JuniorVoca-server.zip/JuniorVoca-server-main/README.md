# JuniorVoca-server
JuniorVoca(아동용 단어 교육 앱) 서버
- [JuniorVoca front-end repo](https://github.com/aeri123443/JuniorVoca)
